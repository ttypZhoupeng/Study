<meta charset="UTF-8">
<?php
	$xingming = $_POST["xingming"];
	$nianling = $_POST["nianling"];
	$qqhao = $_POST["qqhao"];
	
	
	echo "我们已经收到了您的信息！下面请核对内容";
	echo "您的姓名是" . $xingming . "您的年龄是" . $nianling . "您的qq号是" . $qqhao;
?>